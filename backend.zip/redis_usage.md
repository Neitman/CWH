# Caching Trong Hệ Thống 

Tài liệu này trình bày phân tích chi tiết về việc ứng dụng bộ nhớ đệm (Caching) và In-Memory Data Store bằng Redis trong hệ thống CWH. Báo cáo được xây dựng phục vụ việc đánh giá kỹ thuật và thực hiện demo thực tế.

---

## 1. Tổng Quan Kiến Trúc Caching

Hệ thống CWH triển khai **Redis 7** làm lớp lưu trữ bộ nhớ tạm và quản lý trạng thái thời gian thực.

```typescript
import Redis from 'ioredis';

const redis = new Redis(process.env.REDIS_URL || 'redis://localhost:6379');

redis.on('connect', () => {
  console.log('Successfully connected to Redis');
});

export default redis;
```

Vai trò kỹ thuật của Redis trong dự án bao gồm:
1. **Lưu trữ dữ liệu tạm có thời gian sống (TTL - Time-To-Live)**: Quản lý mã OTP đăng ký và khôi phục mật khẩu. Giảm thiểu các thao tác ghi dữ liệu rác xuống cơ sở dữ liệu quan hệ PostgreSQL.
2. **In-Memory Real-time State Store**: Quản lý hàng đợi bài hát (Playlist Queue), tiến trình phát nhạc (Playback Progress), và phân quyền người dùng (Host / Permissions) với độ trễ phản hồi thấp (< 1ms).

---

## 2. Quản Lý Dữ Liệu Tạm Với TTL (OTP Service)

### 2.1. Mục Đích Kỹ Thuật
Đánh giá cơ chế tự động giải phóng bộ nhớ của Redis đối với các dữ liệu có vòng đời ngắn. Phương án này ngăn chặn tình trạng lưu trữ các tài khoản chưa xác minh trong cơ sở dữ liệu chính PostgreSQL, giúp giảm I/O và dung lượng lưu trữ không cần thiết.

### 2.2. Chi Tiết Triển Khai Ví Dụ

#### Ghi dữ liệu OTP tạm thời vào Redis với TTL 300 giây (5 phút)

```typescript
const redisKey = `cwh:register-otp:${normalizedEmail}`;
const payload = JSON.stringify({ username: normalizedUsername, email: normalizedEmail, hashedPassword, otp });
await redis.setex(redisKey, 300, payload);
```

#### Xác thực mã OTP và hủy key bộ nhớ đệm

```typescript
const redisKey = `cwh:register-otp:${normalizedEmail}`;
const dataStr = await redis.get(redisKey);

if (!dataStr) {
  return res.status(400).json({ error: 'Verification code expired or invalid. Please sign up again.' });
}

const payload = JSON.parse(dataStr);
if (payload.otp !== otp.trim()) {
  return res.status(400).json({ error: 'Invalid verification code.' });
}

// Chèn tài khoản vào PostgreSQL sau khi mã OTP hợp lệ
const result = await query(
  'INSERT INTO users (username, email, password) VALUES ($1, $2, $3) RETURNING id, username, email',
  [payload.username, payload.email, payload.hashedPassword]
);

// Xóa key khỏi Redis ngay khi đăng ký thành công
await redis.del(redisKey);
```

### 2.3. Quy Trình Thực Hiện Demo

1. **Bước 1**: Thực hiện yêu cầu đăng ký hoặc khôi phục mật khẩu trên giao diện người dùng để hệ thống phát sinh mã OTP.
2. **Bước 2**: Truy cập Redis CLI để kiểm tra trạng thái bộ nhớ đệm:
   ```bash
   docker exec -it cwh-redis-1 redis-cli
   ```
   Thực hiện truy vấn key và thời gian TTL:
   ```redis
   KEYS cwh:register-otp:*
   GET cwh:register-otp:<email_dang_ky>
   TTL cwh:register-otp:<email_dang_ky>
   ```
3. **Bước 3**: Mô phỏng kịch bản hết hạn bằng cách chờ thời gian TTL đếm ngược về `-2` hoặc thực hiện thủ công lệnh xóa key:
   ```redis
   DEL cwh:register-otp:<email_dang_ky>
   ```
4. **Bước 4**: Gửi lại mã OTP trên giao diện và xác nhận hệ thống trả về thông báo lỗi: `Verification code expired or invalid. Please sign up again.`

---

## 3. Lưu Trữ Trạng Thái Real-time Và Hàng Đợi Playlist

### 3.1. Mục Đích Kỹ Thuật
Đánh giá hiệu năng xử lý của Redis khi đóng vai trò In-Memory State Store cho các tác vụ cập nhật liên tục với độ trễ thấp (< 1ms). Cơ chế này loại bỏ hoàn toàn việc query PostgreSQL liên tục mỗi khi người dùng chuyển bài, thêm bài hoặc đồng bộ tiến trình phát nhạc giữa các client.

### 3.2. Chi Tiết Triển Khai Ví Dụ

#### Quản lý hàng đợi phát nhạc bằng cấu trúc Redis List (`RPUSH`, `LPOP`, `LRANGE`)

```typescript
const getPlaylistKey = (roomId: string) => `cwh:${roomId}:playlist`;

export async function getPlaylistQueue(roomId: string): Promise<Song[]> {
  const key = getPlaylistKey(roomId);
  const items = await redis.lrange(key, 0, -1);
  return items.map(item => JSON.parse(item));
}

export async function addSongToQueue(roomId: string, song: Song): Promise<Song[]> {
  const key = getPlaylistKey(roomId);
  await redis.rpush(key, JSON.stringify(song));
  return getPlaylistQueue(roomId);
}
```

#### Quản lý chủ phòng bằng Lock Atomic (`SETNX`) và danh sách quyền bằng Redis Set

```typescript
export async function setRoomHost(roomId: string, username: string): Promise<boolean> {
  const result = await redis.setnx(`cwh:${roomId}:host`, username);
  return result === 1;
}

export async function hasWritePermission(roomId: string, username: string): Promise<boolean> {
  const host = await getRoomHost(roomId);
  if (!host || username === host) return true;
  
  const isMember = await redis.sismember(`cwh:${roomId}:write_permissions`, username);
  return isMember === 1;
}
```

#### API Xóa Cache Hệ Thống và phát tín hiệu Đồng Bộ Real-time

```typescript
router.post('/redis/flush', async (req: Request, res: Response) => {
  const keys = await redis.keys('cwh:*');
  if (keys.length > 0) {
    await redis.del(...keys);
  }
  
  const io = req.app.get('io') as Server | undefined;
  if (io) {
    io.emit('system-reset', { message: 'Database was flushed by administration.' });
  }

  res.json({ message: `Redis flushed. ${keys.length} keys deleted.` });
});
```

### 3.3. Quy Trình Thực Hiện Demo

1. **Bước 1**: Mở đồng thời 2 phiên truy cập (2 tab trình duyệt) vào cùng một mã phòng.
2. **Bước 2**: Thực hiện các thao tác Thêm bài hát, Tạm dừng, Chuyển bài ở Tab 1. Quan sát sự thay đổi trạng thái theo thời gian thực ở Tab 2.
3. **Bước 3**: Kiểm tra chi tiết cấu trúc dữ liệu lưu giữ tại Redis bằng CLI:
   ```bash
   docker exec -it cwh-redis-1 redis-cli
   ```
   Thực hiện truy vấn cấu trúc dữ liệu:
   ```redis
   KEYS cwh:<roomId>:*
   LRANGE cwh:<roomId>:playlist 0 -1
   GET cwh:<roomId>:current_song
   GET cwh:<roomId>:playback
   GET cwh:<roomId>:host
   ```
4. **Bước 4**: Thực hiện lệnh `POST /api/admin/redis/flush` thông qua Admin Dashboard để kiểm tra phản hồi sự kiện `system-reset` trên cả 2 tab client.

---
